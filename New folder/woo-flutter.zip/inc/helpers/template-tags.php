<?php
/**
 * Custom template tags for the plugin.
 * Contains necessery custom function.
 *
 * @package WooFlutter
 */